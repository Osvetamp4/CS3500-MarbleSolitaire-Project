package org.example;

import org.example.interfaces.MarbleSolitaireModel;
import org.example.interfaces.MarbleSolitaireView;

public class TriangleSolitaireTextView implements MarbleSolitaireView {
  MarbleSolitaireView view;

  public TriangleSolitaireTexView(MarbleSolitaireModel m){
    this.view = new MarbleSolitaireTextView(m);
  }

  public String toString() {

  }

  public void renderBoard() throws IOException {

  }

}
