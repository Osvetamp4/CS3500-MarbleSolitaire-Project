package org.example.interfaces;

import java.io.IOException;

public interface MarbleSolitaireController {
  /*throw an IllegalStateException only if the controller is unable to
  successfully read input or transmit output.
   */
  public void playGame() throws IOException;
}
