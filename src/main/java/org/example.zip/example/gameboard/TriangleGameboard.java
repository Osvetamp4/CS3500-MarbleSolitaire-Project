package org.example.gameboard;

import org.example.gameboard.AbstractGameboard;

public class TriangleGameboard extends AbstractGameboard {
  public TriangleGameboard(){
    this.generateBoard(4);
    this.paintTriangle();
    setPosition(0,0,SlotState.Empty);
  }

  public TriangleGameboard(int sRow, int sCol){
    super();
    if ((sRow < 0 || sRow >= this.board.length || sCol < 0 || sCol >= this.board.length) || getSlotAt(sRow, sCol) == SlotState.Invalid) throw new IllegalArgumentException("Index must be within the confines of the board.");
    else setPosition(sRow,sCol,SlotState.Empty);

  }

  public TriangleGameboard(int thick){
    super(thick);
    setPosition(findMiddle(board.length),findMiddle(board.length),SlotState.Empty);
  }

  public TriangleGameboard(int thick, int sRow, int sCol){
    super(thick);
    if ((sRow < 0 || sRow >= this.board.length || sCol < 0 || sCol >= this.board.length) || getSlotAt(sRow, sCol) == SlotState.Invalid){throw new IllegalArgumentException("Index must be within the confines of the board.");}

    setPosition(sRow,sCol,SlotState.Empty);
  }

  @Override
  protected SlotState[][] generateBoard(int thickness){
    int len = thickness;
    SlotState[][] board = new SlotState[len][len];
    for (int i = 0; i < len; i++){
      for (int j = 0; j < len; j++){
        board[i][j] = SlotState.Invalid;
      }
    }
    return board;

  }

  private void paintTriangle() {
    int len = board.length;

    for (int i = 0; i < len; i++){
      for (int j=0; j < i+1; j++) {
        board[i][j] = SlotState.Marble;
      }
    }
  }

  protected int paintVertical(int t){
    int len = board.length;
    int middle = findMiddle(len);

    for (int i = 0; i < len; i++){
      board[i][middle] = SlotState.Marble;
      int decrement = 0;
      int increment = 0;
      for (int j = t - 1; j > 0; j-=2){
        decrement --;
        increment ++;
        board[i][middle + decrement] = SlotState.Marble;
        board[i][middle + increment] = SlotState.Marble;
      }
      if (i == len - 1) return increment;
    }
    return 6969;
  }

  @Override
  public boolean hasValidMove(int row, int col){

    if (board.length - 1 >= row + 2) {
      if(((board[row+1][col] == SlotState.Marble)
              && (board[row+2][col] == SlotState.Empty))
          || ((board[row+1][col+1] == SlotState.Marble)
              && (board[row+2][col+2] == SlotState.Empty))) { return true;}
    }
    if (row >= 2) {
      if(((board[row-1][col] == SlotState.Marble)
          && (board[row-2][col] == SlotState.Empty))) { return true;}
    }
    if ((row >= 2) && (col >= 2)) {
      if(((board[row-1][col-1] == SlotState.Marble)
          && (board[row-2][col-2] == SlotState.Empty))) { return true;}
    }
    if (col >= 2) {
      if((((board[row][col-1] == SlotState.Marble)
          && (board[row][col-2] == SlotState.Empty)))) { return true;}
        }
    if (col + 2 <= row) {
      if((((board[row][col+1] == SlotState.Marble)
          && (board[row][col+2] == SlotState.Empty)))) { return true;}
    }

    return false;
  }
}

